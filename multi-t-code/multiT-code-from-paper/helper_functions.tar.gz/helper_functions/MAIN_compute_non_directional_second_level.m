function MAIN_compute_non_directional_second_level()
% This function computes second levele results 
results_dir = fullfile('..','..','results');
ffldrs = findFilesBVQX(results_dir,'*RVF*.mat');
% fprintf('The following results folders were found:\n'); 
% for i = 1:length(ffldrs)
%     [pn,fn] = fileparts(ffldrs{i})
%     fprintf('[%d]\t%s\n',i,fn);
% end
% fprintf('enter number of results folder to compute second level on\n'); 
% foldernum = input('what num? ');
% analysisfolder = ffldrs{foldernum}; 
secondlevelresultsfolder = fullfile(results_dir,'2nd_level');
mkdir(secondlevelresultsfolder); 

% subsToExtract = subsUsedGet(20); % 150 / 20 for vocal data set 
fold = 1; 
numMaps = 10;
computeFFXresults(ffldrs,fold,secondlevelresultsfolder,numMaps)
end
